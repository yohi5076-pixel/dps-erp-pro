import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../models/invoice_model.dart';
import '../../models/payment_model.dart';
import '../../services/firestore_service.dart';
import '../../services/report_service.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  DashboardSummary? _summary;
  List<InvoiceModel> _overdue = [];
  List<PaymentModel> _payments = [];
  bool _loading = true;
  final _dateFmt = DateFormat('dd MMM');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final summary = await ReportService.instance.getDashboardSummary();
    final overdue = await ReportService.instance.getOverdueInvoices();
    final payments = await FirestoreService.instance.getPayments();
    if (mounted) {
      setState(() {
        _summary = summary;
        _overdue = overdue;
        _payments = payments;
        _loading = false;
      });
    }
  }

  List<BarChartGroupData> _buildLast7DaysChart() {
    final now = DateTime.now();
    final days = List.generate(7, (i) => DateTime(now.year, now.month, now.day).subtract(Duration(days: 6 - i)));

    return List.generate(7, (i) {
      final day = days[i];
      final total = _payments
          .where((p) => p.paidAt.year == day.year && p.paidAt.month == day.month && p.paidAt.day == day.day)
          .fold(0.0, (sum, p) => sum + p.amount);
      return BarChartGroupData(
        x: i,
        barRods: [BarChartRodData(toY: total, color: AppTheme.primary, width: 18, borderRadius: BorderRadius.circular(4))],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final days = List.generate(7, (i) => DateTime(now.year, now.month, now.day).subtract(Duration(days: 6 - i)));

    return Scaffold(
      appBar: AppBar(title: const Text('Reports')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Text('Collections — Last 7 Days', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(8, 16, 16, 8),
                      child: SizedBox(
                        height: 200,
                        child: BarChart(
                          BarChartData(
                            gridData: const FlGridData(show: false),
                            borderData: FlBorderData(show: false),
                            titlesData: FlTitlesData(
                              leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  getTitlesWidget: (value, meta) {
                                    final idx = value.toInt();
                                    if (idx < 0 || idx >= days.length) return const SizedBox();
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 6),
                                      child: Text(_dateFmt.format(days[idx]), style: const TextStyle(fontSize: 10)),
                                    );
                                  },
                                ),
                              ),
                            ),
                            barGroups: _buildLast7DaysChart(),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text('Summary', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          _summaryRow('Total Revenue Collected', _summary!.totalRevenue),
                          _summaryRow('Total Outstanding', _summary!.totalOutstanding),
                          _countRow('Total Invoices', _summary!.totalInvoices),
                          _countRow('Unpaid Invoices', _summary!.unpaidInvoices),
                          _countRow('Overdue Invoices', _summary!.overdueInvoices),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text('Overdue Invoices', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                  if (_overdue.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('No overdue invoices 🎉', style: TextStyle(color: AppTheme.textSecondary)),
                    )
                  else
                    ..._overdue.map((inv) {
                      final due = ReportService.instance.invoiceBalanceDue(inv, _payments);
                      return Card(
                        child: ListTile(
                          leading: const Icon(Icons.warning_amber_outlined, color: AppTheme.danger),
                          title: Text('${inv.invoiceNumber} · ${inv.customerName}'),
                          subtitle: Text('Due ${_dateFmt.format(inv.dueDate)}'),
                          trailing: Text(
                            '${AppConstants.currencySymbol}${due.toStringAsFixed(0)}',
                            style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.danger),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ),
    );
  }

  Widget _summaryRow(String label, double value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text('${AppConstants.currencySymbol}${value.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _countRow(String label, int value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text('$value', style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
