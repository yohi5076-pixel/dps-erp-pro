import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/backup_service.dart';
import '../../services/audit_service.dart';
import '../../services/auth_service.dart';
import '../../models/audit_model.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_textfield.dart';
import '../../utils/theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _exporting = false;

  Future<void> _exportBackup() async {
    setState(() => _exporting = true);
    try {
      final file = await BackupService.instance.exportBackup();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Backup saved to ${file.path}')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Backup failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _changePassword() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Change Password'),
        content: AppTextField(label: 'New Password', controller: controller, obscureText: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Update')),
        ],
      ),
    );
    if (confirmed != true || controller.text.isEmpty) return;

    final userId = AuthService.instance.currentUser?.id;
    if (userId == null) return;
    await AuthService.instance.changePassword(userId, controller.text);

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password updated')),
    );
  }

  void _viewAuditLog() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const _AuditLogScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.instance.currentUser;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.person_outline),
              title: Text(user?.name ?? ''),
              subtitle: Text('${user?.email ?? ''} · ${user?.role.name ?? ''}'),
            ),
          ),
          const SizedBox(height: 16),
          Text('Data', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.backup_outlined, color: AppTheme.primary),
                  title: const Text('Export Backup'),
                  subtitle: const Text('Save all data as a JSON file'),
                  trailing: _exporting ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : null,
                  onTap: _exporting ? null : _exportBackup,
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.history, color: AppTheme.primary),
                  title: const Text('Audit Log'),
                  subtitle: const Text('View system activity history'),
                  onTap: _viewAuditLog,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text('Account', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock_reset_outlined, color: AppTheme.primary),
              title: const Text('Change Password'),
              onTap: _changePassword,
            ),
          ),
        ],
      ),
    );
  }
}

class _AuditLogScreen extends StatefulWidget {
  const _AuditLogScreen();

  @override
  State<_AuditLogScreen> createState() => _AuditLogScreenState();
}

class _AuditLogScreenState extends State<_AuditLogScreen> {
  List<AuditModel> _logs = [];
  bool _loading = true;
  final _fmt = DateFormat('dd MMM yyyy, hh:mm a');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final logs = await AuditService.instance.getLogs();
    if (mounted) {
      setState(() {
        _logs = logs;
        _loading = false;
      });
    }
  }

  IconData _iconFor(AuditAction action) {
    switch (action) {
      case AuditAction.create:
        return Icons.add_circle_outline;
      case AuditAction.update:
        return Icons.edit_outlined;
      case AuditAction.delete:
        return Icons.delete_outline;
      case AuditAction.login:
        return Icons.login;
      case AuditAction.logout:
        return Icons.logout;
      case AuditAction.payment:
        return Icons.payments_outlined;
      case AuditAction.export:
        return Icons.file_download_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Audit Log')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _logs.isEmpty
              ? const Center(child: Text('No activity yet', style: TextStyle(color: AppTheme.textSecondary)))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _logs.length,
                  itemBuilder: (context, index) {
                    final log = _logs[index];
                    return Card(
                      child: ListTile(
                        leading: Icon(_iconFor(log.action), color: AppTheme.primary),
                        title: Text(log.description.isNotEmpty ? log.description : log.action.name),
                        subtitle: Text('${log.userName} · ${_fmt.format(log.timestamp)}'),
                      ),
                    );
                  },
                ),
    );
  }
}
