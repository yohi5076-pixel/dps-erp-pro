import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../models/invoice_model.dart';
import '../../models/customer_model.dart';
import '../../models/audit_model.dart';
import '../../services/firestore_service.dart';
import '../../services/audit_service.dart';
import '../../widgets/app_button.dart';
import '../../widgets/invoice_item_row.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';

class InvoiceFormScreen extends StatefulWidget {
  const InvoiceFormScreen({super.key});

  @override
  State<InvoiceFormScreen> createState() => _InvoiceFormScreenState();
}

class _InvoiceFormScreenState extends State<InvoiceFormScreen> {
  final _uuid = const Uuid();
  List<CustomerModel> _customers = [];
  CustomerModel? _selectedCustomer;
  DateTime _issueDate = DateTime.now();
  DateTime _dueDate = DateTime.now().add(const Duration(days: 14));
  final List<InvoiceItem> _items = [];
  final _taxController = TextEditingController(text: '0');
  final _discountController = TextEditingController(text: '0');
  final _notesController = TextEditingController();
  bool _saving = false;
  bool _loadingCustomers = true;

  @override
  void initState() {
    super.initState();
    _addItem();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final customers = await FirestoreService.instance.getCustomers();
    customers.sort((a, b) => a.name.compareTo(b.name));
    if (mounted) {
      setState(() {
        _customers = customers;
        _loadingCustomers = false;
      });
    }
  }

  void _addItem() {
    setState(() => _items.add(InvoiceItem(id: _uuid.v4(), description: '')));
  }

  void _removeItem(InvoiceItem item) {
    setState(() => _items.remove(item));
  }

  double get _subtotal => _items.fold(0.0, (sum, i) => sum + i.total);
  double get _taxAmount => _subtotal * ((double.tryParse(_taxController.text) ?? 0) / 100);
  double get _discount => double.tryParse(_discountController.text) ?? 0;
  double get _grandTotal => _subtotal + _taxAmount - _discount;

  Future<void> _pickDate({required bool isIssueDate}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: isIssueDate ? _issueDate : _dueDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isIssueDate) {
          _issueDate = picked;
        } else {
          _dueDate = picked;
        }
      });
    }
  }

  Future<void> _save() async {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a customer')),
      );
      return;
    }
    final validItems = _items.where((i) => i.description.trim().isNotEmpty).toList();
    if (validItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add at least one item')),
      );
      return;
    }

    setState(() => _saving = true);

    final number = await FirestoreService.instance.nextInvoiceNumber();
    final invoice = InvoiceModel(
      id: _uuid.v4(),
      invoiceNumber: 'INV-$number',
      customerId: _selectedCustomer!.id,
      customerName: _selectedCustomer!.name,
      issueDate: _issueDate,
      dueDate: _dueDate,
      items: validItems,
      taxPercent: double.tryParse(_taxController.text) ?? 0,
      discount: _discount,
      status: InvoiceStatus.unpaid,
      notes: _notesController.text.trim(),
      createdAt: DateTime.now(),
    );

    await FirestoreService.instance.saveInvoice(invoice);
    await AuditService.instance.log(
      action: AuditAction.create,
      entityType: 'invoice',
      entityId: invoice.id,
      description: 'Invoice ${invoice.invoiceNumber} created for ${invoice.customerName}',
    );

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Invoice')),
      body: _loadingCustomers
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                DropdownButtonFormField<CustomerModel>(
                  value: _selectedCustomer,
                  decoration: const InputDecoration(labelText: 'Customer'),
                  items: _customers
                      .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                      .toList(),
                  onChanged: (c) => setState(() => _selectedCustomer = c),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickDate(isIssueDate: true),
                        icon: const Icon(Icons.calendar_today_outlined, size: 16),
                        label: Text('Issue: ${_issueDate.toString().split(' ').first}'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _pickDate(isIssueDate: false),
                        icon: const Icon(Icons.event_outlined, size: 16),
                        label: Text('Due: ${_dueDate.toString().split(' ').first}'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                Text('Items', style: Theme.of(context).textTheme.titleMedium),
                const Divider(),
                ..._items.map((item) => InvoiceItemRow(
                      item: item,
                      onRemove: () => _removeItem(item),
                      onChanged: () => setState(() {}),
                    )),
                TextButton.icon(
                  onPressed: _addItem,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Add Item'),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _taxController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Tax %'),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _discountController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(labelText: 'Discount (${AppConstants.currencySymbol})'),
                        onChanged: (_) => setState(() {}),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _notesController,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'Notes (optional)'),
                ),
                const SizedBox(height: 20),
                Card(
                  color: AppTheme.background,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _summaryRow('Subtotal', _subtotal),
                        _summaryRow('Tax', _taxAmount),
                        _summaryRow('Discount', -_discount),
                        const Divider(),
                        _summaryRow('Grand Total', _grandTotal, bold: true),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                AppButton(
                  label: 'Create Invoice',
                  onPressed: _save,
                  isLoading: _saving,
                  fullWidth: true,
                ),
              ],
            ),
    );
  }

  Widget _summaryRow(String label, double value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          Text(
            '${AppConstants.currencySymbol}${value.toStringAsFixed(2)}',
            style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal),
          ),
        ],
      ),
    );
  }
}
