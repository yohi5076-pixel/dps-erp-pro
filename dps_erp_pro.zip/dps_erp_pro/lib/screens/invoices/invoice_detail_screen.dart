import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../models/invoice_model.dart';
import '../../models/customer_model.dart';
import '../../models/payment_model.dart';
import '../../models/audit_model.dart';
import '../../services/firestore_service.dart';
import '../../services/report_service.dart';
import '../../services/pdf_service.dart';
import '../../services/audit_service.dart';
import '../../widgets/app_button.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';

class InvoiceDetailScreen extends StatefulWidget {
  final String invoiceId;
  const InvoiceDetailScreen({super.key, required this.invoiceId});

  @override
  State<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends State<InvoiceDetailScreen> {
  InvoiceModel? _invoice;
  CustomerModel? _customer;
  List<PaymentModel> _payments = [];
  bool _loading = true;
  final _dateFmt = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final invoices = await FirestoreService.instance.getInvoices();
    final invoice = invoices.firstWhere((i) => i.id == widget.invoiceId);
    final customers = await FirestoreService.instance.getCustomers();
    final customer = customers.firstWhere((c) => c.id == invoice.customerId);
    final payments = await FirestoreService.instance.getPaymentsForInvoice(invoice.id);

    if (mounted) {
      setState(() {
        _invoice = invoice;
        _customer = customer;
        _payments = payments;
        _loading = false;
      });
    }
  }

  Future<void> _recordPayment() async {
    final invoice = _invoice!;
    final due = ReportService.instance.invoiceBalanceDue(invoice, _payments);
    final amountController = TextEditingController(text: due.toStringAsFixed(2));
    PaymentMethod method = PaymentMethod.cash;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Record Payment'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: 'Amount (${AppConstants.currencySymbol})'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<PaymentMethod>(
                value: method,
                decoration: const InputDecoration(labelText: 'Method'),
                items: PaymentMethod.values
                    .map((m) => DropdownMenuItem(value: m, child: Text(m.name)))
                    .toList(),
                onChanged: (m) => setDialogState(() => method = m ?? PaymentMethod.cash),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
          ],
        ),
      ),
    );

    if (confirmed != true) return;
    final amount = double.tryParse(amountController.text) ?? 0;
    if (amount <= 0) return;

    final payment = PaymentModel(
      id: const Uuid().v4(),
      invoiceId: invoice.id,
      customerId: invoice.customerId,
      amount: amount,
      method: method,
      paidAt: DateTime.now(),
    );
    await FirestoreService.instance.savePayment(payment);

    final newPayments = [..._payments, payment];
    final newDue = ReportService.instance.invoiceBalanceDue(invoice, newPayments);
    final newStatus = newDue <= 0
        ? InvoiceStatus.paid
        : newPayments.isNotEmpty
            ? InvoiceStatus.partiallyPaid
            : InvoiceStatus.unpaid;

    final updatedInvoice = invoice.copyWith(status: newStatus);
    await FirestoreService.instance.saveInvoice(updatedInvoice);

    await AuditService.instance.log(
      action: AuditAction.payment,
      entityType: 'invoice',
      entityId: invoice.id,
      description: 'Payment of ${AppConstants.currencySymbol}${amount.toStringAsFixed(2)} recorded for ${invoice.invoiceNumber}',
    );

    _load();
  }

  Future<void> _sharePdf() async {
    if (_invoice == null || _customer == null) return;
    await PdfService.instance.shareOrPrintInvoice(invoice: _invoice!, customer: _customer!);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _invoice == null || _customer == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final invoice = _invoice!;
    final due = ReportService.instance.invoiceBalanceDue(invoice, _payments);

    return Scaffold(
      appBar: AppBar(
        title: Text(invoice.invoiceNumber),
        actions: [
          IconButton(icon: const Icon(Icons.picture_as_pdf_outlined), onPressed: _sharePdf),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_customer!.name, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text('Issued ${_dateFmt.format(invoice.issueDate)} · Due ${_dateFmt.format(invoice.dueDate)}',
                      style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Grand Total', style: Theme.of(context).textTheme.bodyMedium),
                      Text('${AppConstants.currencySymbol}${invoice.grandTotal.toStringAsFixed(2)}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Balance Due'),
                      Text(
                        '${AppConstants.currencySymbol}${due.toStringAsFixed(2)}',
                        style: TextStyle(fontWeight: FontWeight.bold, color: due > 0 ? AppTheme.danger : AppTheme.accent),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('Items', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Card(
            child: Column(
              children: invoice.items
                  .map((item) => ListTile(
                        title: Text(item.description),
                        subtitle: Text('${item.quantity} × ${AppConstants.currencySymbol}${item.rate.toStringAsFixed(2)}'),
                        trailing: Text('${AppConstants.currencySymbol}${item.total.toStringAsFixed(2)}'),
                      ))
                  .toList(),
            ),
          ),
          const SizedBox(height: 16),
          Text('Payments', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_payments.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('No payments recorded yet', style: TextStyle(color: AppTheme.textSecondary)),
            )
          else
            Card(
              child: Column(
                children: _payments
                    .map((p) => ListTile(
                          leading: const Icon(Icons.payments_outlined, color: AppTheme.accent),
                          title: Text('${AppConstants.currencySymbol}${p.amount.toStringAsFixed(2)}'),
                          subtitle: Text('${p.method.name} · ${_dateFmt.format(p.paidAt)}'),
                        ))
                    .toList(),
              ),
            ),
          const SizedBox(height: 24),
          if (due > 0)
            AppButton(
              label: 'Record Payment',
              onPressed: _recordPayment,
              icon: Icons.add_card_outlined,
              fullWidth: true,
            ),
        ],
      ),
    );
  }
}
