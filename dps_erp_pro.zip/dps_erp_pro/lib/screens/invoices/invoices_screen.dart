import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/invoice_model.dart';
import '../../models/payment_model.dart';
import '../../services/firestore_service.dart';
import '../../services/report_service.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';
import 'invoice_form_screen.dart';
import 'invoice_detail_screen.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  List<InvoiceModel> _invoices = [];
  List<PaymentModel> _payments = [];
  bool _loading = true;
  InvoiceStatus? _filter;
  final _dateFmt = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final invoices = await FirestoreService.instance.getInvoices();
    final payments = await FirestoreService.instance.getPayments();
    invoices.sort((a, b) => b.issueDate.compareTo(a.issueDate));
    if (mounted) {
      setState(() {
        _invoices = invoices;
        _payments = payments;
        _loading = false;
      });
    }
  }

  List<InvoiceModel> get _filtered {
    if (_filter == null) return _invoices;
    return _invoices.where((i) => i.status == _filter).toList();
  }

  Color _statusColor(InvoiceStatus status) {
    switch (status) {
      case InvoiceStatus.paid:
        return AppTheme.accent;
      case InvoiceStatus.partiallyPaid:
        return AppTheme.warning;
      case InvoiceStatus.unpaid:
        return AppTheme.danger;
      case InvoiceStatus.draft:
        return AppTheme.textSecondary;
      case InvoiceStatus.cancelled:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Invoices')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceFormScreen()));
          _load();
        },
        icon: const Icon(Icons.add),
        label: const Text('New Invoice'),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                _filterChip('All', null),
                ...InvoiceStatus.values.map((s) => _filterChip(_statusLabel(s), s)),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? const Center(child: Text('No invoices found', style: TextStyle(color: AppTheme.textSecondary)))
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        itemCount: _filtered.length,
                        itemBuilder: (context, index) {
                          final invoice = _filtered[index];
                          final due = ReportService.instance.invoiceBalanceDue(invoice, _payments);
                          return Card(
                            child: ListTile(
                              title: Text('#${invoice.invoiceNumber} · ${invoice.customerName}'),
                              subtitle: Text('Issued ${_dateFmt.format(invoice.issueDate)} · Due ${_dateFmt.format(invoice.dueDate)}'),
                              trailing: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    '${AppConstants.currencySymbol}${invoice.grandTotal.toStringAsFixed(0)}',
                                    style: const TextStyle(fontWeight: FontWeight.w600),
                                  ),
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: _statusColor(invoice.status).withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Text(
                                      due > 0 ? 'Due ${AppConstants.currencySymbol}${due.toStringAsFixed(0)}' : _statusLabel(invoice.status),
                                      style: TextStyle(fontSize: 11, color: _statusColor(invoice.status), fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                ],
                              ),
                              onTap: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) => InvoiceDetailScreen(invoiceId: invoice.id)),
                                );
                                _load();
                              },
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  String _statusLabel(InvoiceStatus status) {
    switch (status) {
      case InvoiceStatus.draft:
        return 'Draft';
      case InvoiceStatus.unpaid:
        return 'Unpaid';
      case InvoiceStatus.partiallyPaid:
        return 'Partial';
      case InvoiceStatus.paid:
        return 'Paid';
      case InvoiceStatus.cancelled:
        return 'Cancelled';
    }
  }

  Widget _filterChip(String label, InvoiceStatus? status) {
    final selected = _filter == status;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _filter = status),
        selectedColor: AppTheme.primary.withOpacity(0.15),
        labelStyle: TextStyle(color: selected ? AppTheme.primary : AppTheme.textPrimary),
      ),
    );
  }
}
