import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/report_service.dart';
import '../../services/audit_service.dart';
import '../../models/audit_model.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';
import '../../widgets/dashboard_card.dart';
import '../customers/customers_screen.dart';
import '../invoices/invoices_screen.dart';
import '../ledger/ledger_screen.dart';
import '../reports/reports_screen.dart';
import '../users/users_screen.dart';
import '../settings/settings_screen.dart';
import '../login/login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  DashboardSummary? _summary;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final summary = await ReportService.instance.getDashboardSummary();
    if (mounted) setState(() => _summary = summary);
  }

  Future<void> _logout() async {
    final user = AuthService.instance.currentUser;
    if (user != null) {
      await AuditService.instance.log(
        action: AuditAction.logout,
        entityType: 'user',
        entityId: user.id,
        description: '${user.name} logged out',
      );
    }
    await AuthService.instance.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.instance.currentUser;
    final currency = AppConstants.currencySymbol;

    return Scaffold(
      appBar: AppBar(
        title: Text(AppConstants.appName),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: _logout,
          ),
        ],
      ),
      drawer: _buildDrawer(context, user?.role.name ?? ''),
      body: RefreshIndicator(
        onRefresh: _load,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Welcome back, ${user?.name ?? ''}',
                  style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 4),
              const Text('Here\'s what\'s happening in your business.',
                  style: TextStyle(color: AppTheme.textSecondary)),
              const SizedBox(height: 20),
              if (_summary == null)
                const Center(child: Padding(
                  padding: EdgeInsets.all(32),
                  child: CircularProgressIndicator(),
                ))
              else
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.3,
                  children: [
                    DashboardCard(
                      title: 'Revenue Collected',
                      value: '$currency${_summary!.totalRevenue.toStringAsFixed(0)}',
                      icon: Icons.trending_up,
                      color: AppTheme.accent,
                      onTap: () => _goTo(context, const ReportsScreen()),
                    ),
                    DashboardCard(
                      title: 'Outstanding',
                      value: '$currency${_summary!.totalOutstanding.toStringAsFixed(0)}',
                      icon: Icons.account_balance_wallet_outlined,
                      color: AppTheme.warning,
                      onTap: () => _goTo(context, const InvoicesScreen()),
                    ),
                    DashboardCard(
                      title: 'Total Invoices',
                      value: '${_summary!.totalInvoices}',
                      icon: Icons.receipt_long_outlined,
                      color: AppTheme.primary,
                      onTap: () => _goTo(context, const InvoicesScreen()),
                    ),
                    DashboardCard(
                      title: 'Customers',
                      value: '${_summary!.totalCustomers}',
                      icon: Icons.people_outline,
                      color: AppTheme.primaryLight,
                      onTap: () => _goTo(context, const CustomersScreen()),
                    ),
                    DashboardCard(
                      title: 'Unpaid Invoices',
                      value: '${_summary!.unpaidInvoices}',
                      icon: Icons.pending_actions_outlined,
                      color: AppTheme.warning,
                    ),
                    DashboardCard(
                      title: 'Overdue',
                      value: '${_summary!.overdueInvoices}',
                      icon: Icons.warning_amber_outlined,
                      color: AppTheme.danger,
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  void _goTo(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Widget _buildDrawer(BuildContext context, String role) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: AppTheme.primary),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                const Icon(Icons.business_center_rounded, color: Colors.white, size: 36),
                const SizedBox(height: 8),
                Text(AppConstants.appName,
                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                Text(role.toUpperCase(),
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.dashboard_outlined),
            title: const Text('Dashboard'),
            onTap: () => Navigator.pop(context),
          ),
          ListTile(
            leading: const Icon(Icons.people_outline),
            title: const Text('Customers'),
            onTap: () {
              Navigator.pop(context);
              _goTo(context, const CustomersScreen());
            },
          ),
          ListTile(
            leading: const Icon(Icons.receipt_long_outlined),
            title: const Text('Invoices'),
            onTap: () {
              Navigator.pop(context);
              _goTo(context, const InvoicesScreen());
            },
          ),
          ListTile(
            leading: const Icon(Icons.book_outlined),
            title: const Text('Ledger'),
            onTap: () {
              Navigator.pop(context);
              _goTo(context, const LedgerScreen());
            },
          ),
          ListTile(
            leading: const Icon(Icons.bar_chart_outlined),
            title: const Text('Reports'),
            onTap: () {
              Navigator.pop(context);
              _goTo(context, const ReportsScreen());
            },
          ),
          if (role == 'admin')
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: const Text('Users'),
              onTap: () {
                Navigator.pop(context);
                _goTo(context, const UsersScreen());
              },
            ),
          ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('Settings'),
            onTap: () {
              Navigator.pop(context);
              _goTo(context, const SettingsScreen());
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.logout, color: AppTheme.danger),
            title: const Text('Logout', style: TextStyle(color: AppTheme.danger)),
            onTap: () {
              Navigator.pop(context);
              _logout();
            },
          ),
        ],
      ),
    );
  }
}
