import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../models/customer_model.dart';
import '../../models/audit_model.dart';
import '../../services/firestore_service.dart';
import '../../services/audit_service.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_textfield.dart';
import '../../utils/theme.dart';

class CustomerFormScreen extends StatefulWidget {
  final CustomerModel? customer;
  const CustomerFormScreen({super.key, this.customer});

  @override
  State<CustomerFormScreen> createState() => _CustomerFormScreenState();
}

class _CustomerFormScreenState extends State<CustomerFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _name;
  late TextEditingController _phone;
  late TextEditingController _email;
  late TextEditingController _address;
  late TextEditingController _gst;
  late TextEditingController _openingBalance;
  bool _saving = false;

  bool get _isEditing => widget.customer != null;

  @override
  void initState() {
    super.initState();
    final c = widget.customer;
    _name = TextEditingController(text: c?.name ?? '');
    _phone = TextEditingController(text: c?.phone ?? '');
    _email = TextEditingController(text: c?.email ?? '');
    _address = TextEditingController(text: c?.address ?? '');
    _gst = TextEditingController(text: c?.gstNumber ?? '');
    _openingBalance = TextEditingController(text: (c?.openingBalance ?? 0).toStringAsFixed(2));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final customer = CustomerModel(
      id: widget.customer?.id ?? const Uuid().v4(),
      name: _name.text.trim(),
      phone: _phone.text.trim(),
      email: _email.text.trim(),
      address: _address.text.trim(),
      gstNumber: _gst.text.trim(),
      openingBalance: double.tryParse(_openingBalance.text) ?? 0,
      createdAt: widget.customer?.createdAt ?? DateTime.now(),
    );

    await FirestoreService.instance.saveCustomer(customer);
    await AuditService.instance.log(
      action: _isEditing ? AuditAction.update : AuditAction.create,
      entityType: 'customer',
      entityId: customer.id,
      description: 'Customer "${customer.name}" ${_isEditing ? 'updated' : 'created'}',
    );

    if (!mounted) return;
    Navigator.pop(context);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete customer?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: AppTheme.danger)),
          ),
        ],
      ),
    );
    if (confirmed != true || widget.customer == null) return;

    await FirestoreService.instance.deleteCustomer(widget.customer!.id);
    await AuditService.instance.log(
      action: AuditAction.delete,
      entityType: 'customer',
      entityId: widget.customer!.id,
      description: 'Customer "${widget.customer!.name}" deleted',
    );

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Customer' : 'New Customer'),
        actions: [
          if (_isEditing)
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: _delete),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            AppTextField(
              label: 'Full Name',
              controller: _name,
              prefixIcon: Icons.person_outline,
              validator: (v) => (v == null || v.isEmpty) ? 'Name is required' : null,
            ),
            const SizedBox(height: 14),
            AppTextField(
              label: 'Phone',
              controller: _phone,
              keyboardType: TextInputType.phone,
              prefixIcon: Icons.phone_outlined,
            ),
            const SizedBox(height: 14),
            AppTextField(
              label: 'Email',
              controller: _email,
              keyboardType: TextInputType.emailAddress,
              prefixIcon: Icons.email_outlined,
            ),
            const SizedBox(height: 14),
            AppTextField(
              label: 'Address',
              controller: _address,
              maxLines: 2,
              prefixIcon: Icons.location_on_outlined,
            ),
            const SizedBox(height: 14),
            AppTextField(
              label: 'GST Number (optional)',
              controller: _gst,
              prefixIcon: Icons.badge_outlined,
            ),
            const SizedBox(height: 14),
            AppTextField(
              label: 'Opening Balance',
              controller: _openingBalance,
              keyboardType: TextInputType.number,
              prefixIcon: Icons.account_balance_wallet_outlined,
            ),
            const SizedBox(height: 28),
            AppButton(
              label: _isEditing ? 'Save Changes' : 'Add Customer',
              onPressed: _save,
              isLoading: _saving,
              fullWidth: true,
            ),
          ],
        ),
      ),
    );
  }
}
