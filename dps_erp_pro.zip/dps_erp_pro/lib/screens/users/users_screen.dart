import 'package:flutter/material.dart';
import '../../models/user_model.dart';
import '../../models/audit_model.dart';
import '../../services/firestore_service.dart';
import '../../services/auth_service.dart';
import '../../services/audit_service.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_textfield.dart';
import '../../utils/theme.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  List<UserModel> _users = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final users = await FirestoreService.instance.getUsers();
    if (mounted) {
      setState(() {
        _users = users;
        _loading = false;
      });
    }
  }

  Future<void> _toggleActive(UserModel user) async {
    if (user.id == AuthService.instance.currentUser?.id) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You cannot deactivate your own account')),
      );
      return;
    }
    final updated = user.copyWith(isActive: !user.isActive);
    await FirestoreService.instance.saveUser(updated);
    await AuditService.instance.log(
      action: AuditAction.update,
      entityType: 'user',
      entityId: user.id,
      description: '${user.name} ${updated.isActive ? 'activated' : 'deactivated'}',
    );
    _load();
  }

  Future<void> _addUser() async {
    final nameController = TextEditingController();
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    UserRole role = UserRole.staff;

    final created = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Add User'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AppTextField(label: 'Name', controller: nameController),
                const SizedBox(height: 12),
                AppTextField(label: 'Email', controller: emailController, keyboardType: TextInputType.emailAddress),
                const SizedBox(height: 12),
                AppTextField(label: 'Password', controller: passwordController, obscureText: true),
                const SizedBox(height: 12),
                DropdownButtonFormField<UserRole>(
                  value: role,
                  decoration: const InputDecoration(labelText: 'Role'),
                  items: UserRole.values.map((r) => DropdownMenuItem(value: r, child: Text(r.name))).toList(),
                  onChanged: (r) => setDialogState(() => role = r ?? UserRole.staff),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create')),
          ],
        ),
      ),
    );

    if (created != true) return;
    if (nameController.text.trim().isEmpty || emailController.text.trim().isEmpty || passwordController.text.isEmpty) {
      return;
    }

    final user = await AuthService.instance.createUser(
      name: nameController.text.trim(),
      email: emailController.text.trim(),
      password: passwordController.text,
      role: role,
    );

    await AuditService.instance.log(
      action: AuditAction.create,
      entityType: 'user',
      entityId: user.id,
      description: 'User ${user.name} created with role ${user.role.name}',
    );

    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Users')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addUser,
        icon: const Icon(Icons.person_add_alt_outlined),
        label: const Text('Add User'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _users.length,
              itemBuilder: (context, index) {
                final user = _users[index];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppTheme.primary.withOpacity(0.12),
                      child: Text(user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                          style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.bold)),
                    ),
                    title: Text(user.name),
                    subtitle: Text('${user.email} · ${user.role.name}'),
                    trailing: Switch(
                      value: user.isActive,
                      onChanged: (_) => _toggleActive(user),
                      activeColor: AppTheme.accent,
                    ),
                  ),
                );
              },
            ),
    );
  }
}
