import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/customer_model.dart';
import '../../services/firestore_service.dart';
import '../../services/report_service.dart';
import '../../utils/theme.dart';
import '../../utils/constants.dart';

class LedgerScreen extends StatefulWidget {
  const LedgerScreen({super.key});

  @override
  State<LedgerScreen> createState() => _LedgerScreenState();
}

class _LedgerScreenState extends State<LedgerScreen> {
  List<CustomerModel> _customers = [];
  CustomerModel? _selected;
  List<CustomerLedgerEntry> _entries = [];
  bool _loadingCustomers = true;
  bool _loadingLedger = false;
  final _dateFmt = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _loadCustomers();
  }

  Future<void> _loadCustomers() async {
    final customers = await FirestoreService.instance.getCustomers();
    customers.sort((a, b) => a.name.compareTo(b.name));
    if (mounted) {
      setState(() {
        _customers = customers;
        _loadingCustomers = false;
      });
    }
  }

  Future<void> _selectCustomer(CustomerModel customer) async {
    setState(() {
      _selected = customer;
      _loadingLedger = true;
    });
    final entries = await ReportService.instance.getCustomerLedger(customer);
    if (mounted) {
      setState(() {
        _entries = entries;
        _loadingLedger = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Customer Ledger')),
      body: _loadingCustomers
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: DropdownButtonFormField<CustomerModel>(
                    value: _selected,
                    decoration: const InputDecoration(labelText: 'Select Customer'),
                    items: _customers
                        .map((c) => DropdownMenuItem(value: c, child: Text(c.name)))
                        .toList(),
                    onChanged: (c) {
                      if (c != null) _selectCustomer(c);
                    },
                  ),
                ),
                if (_selected != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Card(
                      color: AppTheme.primary.withOpacity(0.06),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Current Balance', style: TextStyle(fontWeight: FontWeight.w600)),
                            Text(
                              '${AppConstants.currencySymbol}${(_entries.isNotEmpty ? _entries.last.runningBalance : _selected!.openingBalance).toStringAsFixed(2)}',
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppTheme.primary),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                Expanded(
                  child: _selected == null
                      ? const Center(
                          child: Text('Select a customer to view their ledger', style: TextStyle(color: AppTheme.textSecondary)))
                      : _loadingLedger
                          ? const Center(child: CircularProgressIndicator())
                          : _entries.isEmpty
                              ? const Center(child: Text('No transactions yet', style: TextStyle(color: AppTheme.textSecondary)))
                              : ListView.builder(
                                  padding: const EdgeInsets.all(12),
                                  itemCount: _entries.length,
                                  itemBuilder: (context, index) {
                                    final e = _entries[index];
                                    final isDebit = e.debit > 0;
                                    return Card(
                                      child: ListTile(
                                        leading: Icon(
                                          isDebit ? Icons.arrow_upward : Icons.arrow_downward,
                                          color: isDebit ? AppTheme.danger : AppTheme.accent,
                                        ),
                                        title: Text(e.description),
                                        subtitle: Text(_dateFmt.format(e.date)),
                                        trailing: Column(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Text(
                                              '${isDebit ? '+' : '-'}${AppConstants.currencySymbol}${(isDebit ? e.debit : e.credit).toStringAsFixed(2)}',
                                              style: TextStyle(
                                                fontWeight: FontWeight.w600,
                                                color: isDebit ? AppTheme.danger : AppTheme.accent,
                                              ),
                                            ),
                                            Text(
                                              'Bal: ${AppConstants.currencySymbol}${e.runningBalance.toStringAsFixed(2)}',
                                              style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary),
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  },
                                ),
                ),
              ],
            ),
    );
  }
}
