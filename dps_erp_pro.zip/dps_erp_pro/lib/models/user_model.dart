enum UserRole { admin, manager, staff }

class UserModel {
  final String id;
  final String name;
  final String email;
  final String passwordHash;
  final UserRole role;
  final bool isActive;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.passwordHash,
    required this.role,
    this.isActive = true,
    required this.createdAt,
  });

  UserModel copyWith({
    String? name,
    String? email,
    String? passwordHash,
    UserRole? role,
    bool? isActive,
  }) {
    return UserModel(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      passwordHash: passwordHash ?? this.passwordHash,
      role: role ?? this.role,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'email': email,
        'passwordHash': passwordHash,
        'role': role.name,
        'isActive': isActive,
        'createdAt': createdAt.toIso8601String(),
      };

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
        id: map['id'],
        name: map['name'],
        email: map['email'],
        passwordHash: map['passwordHash'],
        role: UserRole.values.firstWhere((r) => r.name == map['role']),
        isActive: map['isActive'] ?? true,
        createdAt: DateTime.parse(map['createdAt']),
      );
}
