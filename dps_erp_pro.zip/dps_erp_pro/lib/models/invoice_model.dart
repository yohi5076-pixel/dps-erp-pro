enum InvoiceStatus { draft, unpaid, partiallyPaid, paid, cancelled }

class InvoiceItem {
  final String id;
  String description;
  double quantity;
  double rate;

  InvoiceItem({
    required this.id,
    required this.description,
    this.quantity = 1,
    this.rate = 0,
  });

  double get total => quantity * rate;

  Map<String, dynamic> toMap() => {
        'id': id,
        'description': description,
        'quantity': quantity,
        'rate': rate,
      };

  factory InvoiceItem.fromMap(Map<String, dynamic> map) => InvoiceItem(
        id: map['id'],
        description: map['description'],
        quantity: (map['quantity'] ?? 1).toDouble(),
        rate: (map['rate'] ?? 0).toDouble(),
      );
}

class InvoiceModel {
  final String id;
  final String invoiceNumber;
  final String customerId;
  final String customerName;
  final DateTime issueDate;
  final DateTime dueDate;
  final List<InvoiceItem> items;
  final double taxPercent;
  final double discount;
  final InvoiceStatus status;
  final String notes;
  final DateTime createdAt;

  InvoiceModel({
    required this.id,
    required this.invoiceNumber,
    required this.customerId,
    required this.customerName,
    required this.issueDate,
    required this.dueDate,
    required this.items,
    this.taxPercent = 0,
    this.discount = 0,
    this.status = InvoiceStatus.unpaid,
    this.notes = '',
    required this.createdAt,
  });

  double get subtotal => items.fold(0.0, (sum, item) => sum + item.total);
  double get taxAmount => subtotal * (taxPercent / 100);
  double get grandTotal => subtotal + taxAmount - discount;

  InvoiceModel copyWith({
    String? customerId,
    String? customerName,
    DateTime? issueDate,
    DateTime? dueDate,
    List<InvoiceItem>? items,
    double? taxPercent,
    double? discount,
    InvoiceStatus? status,
    String? notes,
  }) {
    return InvoiceModel(
      id: id,
      invoiceNumber: invoiceNumber,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      issueDate: issueDate ?? this.issueDate,
      dueDate: dueDate ?? this.dueDate,
      items: items ?? this.items,
      taxPercent: taxPercent ?? this.taxPercent,
      discount: discount ?? this.discount,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'invoiceNumber': invoiceNumber,
        'customerId': customerId,
        'customerName': customerName,
        'issueDate': issueDate.toIso8601String(),
        'dueDate': dueDate.toIso8601String(),
        'items': items.map((e) => e.toMap()).toList(),
        'taxPercent': taxPercent,
        'discount': discount,
        'status': status.name,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory InvoiceModel.fromMap(Map<String, dynamic> map) => InvoiceModel(
        id: map['id'],
        invoiceNumber: map['invoiceNumber'],
        customerId: map['customerId'],
        customerName: map['customerName'],
        issueDate: DateTime.parse(map['issueDate']),
        dueDate: DateTime.parse(map['dueDate']),
        items: (map['items'] as List)
            .map((e) => InvoiceItem.fromMap(Map<String, dynamic>.from(e)))
            .toList(),
        taxPercent: (map['taxPercent'] ?? 0).toDouble(),
        discount: (map['discount'] ?? 0).toDouble(),
        status: InvoiceStatus.values.firstWhere((s) => s.name == map['status']),
        notes: map['notes'] ?? '',
        createdAt: DateTime.parse(map['createdAt']),
      );
}
