class CustomerModel {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String address;
  final String gstNumber;
  final double openingBalance;
  final DateTime createdAt;

  CustomerModel({
    required this.id,
    required this.name,
    this.phone = '',
    this.email = '',
    this.address = '',
    this.gstNumber = '',
    this.openingBalance = 0.0,
    required this.createdAt,
  });

  CustomerModel copyWith({
    String? name,
    String? phone,
    String? email,
    String? address,
    String? gstNumber,
    double? openingBalance,
  }) {
    return CustomerModel(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      email: email ?? this.email,
      address: address ?? this.address,
      gstNumber: gstNumber ?? this.gstNumber,
      openingBalance: openingBalance ?? this.openingBalance,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'phone': phone,
        'email': email,
        'address': address,
        'gstNumber': gstNumber,
        'openingBalance': openingBalance,
        'createdAt': createdAt.toIso8601String(),
      };

  factory CustomerModel.fromMap(Map<String, dynamic> map) => CustomerModel(
        id: map['id'],
        name: map['name'],
        phone: map['phone'] ?? '',
        email: map['email'] ?? '',
        address: map['address'] ?? '',
        gstNumber: map['gstNumber'] ?? '',
        openingBalance: (map['openingBalance'] ?? 0.0).toDouble(),
        createdAt: DateTime.parse(map['createdAt']),
      );
}
