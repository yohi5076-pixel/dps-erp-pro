enum PaymentMethod { cash, bankTransfer, card, upi, cheque, other }

class PaymentModel {
  final String id;
  final String invoiceId;
  final String customerId;
  final double amount;
  final PaymentMethod method;
  final DateTime paidAt;
  final String reference;
  final String notes;

  PaymentModel({
    required this.id,
    required this.invoiceId,
    required this.customerId,
    required this.amount,
    required this.method,
    required this.paidAt,
    this.reference = '',
    this.notes = '',
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'invoiceId': invoiceId,
        'customerId': customerId,
        'amount': amount,
        'method': method.name,
        'paidAt': paidAt.toIso8601String(),
        'reference': reference,
        'notes': notes,
      };

  factory PaymentModel.fromMap(Map<String, dynamic> map) => PaymentModel(
        id: map['id'],
        invoiceId: map['invoiceId'],
        customerId: map['customerId'],
        amount: (map['amount'] ?? 0).toDouble(),
        method: PaymentMethod.values.firstWhere((m) => m.name == map['method']),
        paidAt: DateTime.parse(map['paidAt']),
        reference: map['reference'] ?? '',
        notes: map['notes'] ?? '',
      );
}
