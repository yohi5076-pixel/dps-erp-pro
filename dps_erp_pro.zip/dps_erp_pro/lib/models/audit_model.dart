enum AuditAction { create, update, delete, login, logout, payment, export }

class AuditModel {
  final String id;
  final String userId;
  final String userName;
  final AuditAction action;
  final String entityType;
  final String entityId;
  final String description;
  final DateTime timestamp;

  AuditModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.action,
    required this.entityType,
    required this.entityId,
    this.description = '',
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'userId': userId,
        'userName': userName,
        'action': action.name,
        'entityType': entityType,
        'entityId': entityId,
        'description': description,
        'timestamp': timestamp.toIso8601String(),
      };

  factory AuditModel.fromMap(Map<String, dynamic> map) => AuditModel(
        id: map['id'],
        userId: map['userId'],
        userName: map['userName'],
        action: AuditAction.values.firstWhere((a) => a.name == map['action']),
        entityType: map['entityType'],
        entityId: map['entityId'],
        description: map['description'] ?? '',
        timestamp: DateTime.parse(map['timestamp']),
      );
}
