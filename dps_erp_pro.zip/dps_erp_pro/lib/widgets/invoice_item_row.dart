import 'package:flutter/material.dart';
import '../models/invoice_model.dart';
import '../utils/constants.dart';

class InvoiceItemRow extends StatelessWidget {
  final InvoiceItem item;
  final VoidCallback onRemove;
  final VoidCallback onChanged;

  const InvoiceItemRow({
    super.key,
    required this.item,
    required this.onRemove,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final descController = TextEditingController(text: item.description);
    final qtyController = TextEditingController(text: item.quantity.toStringAsFixed(0));
    final rateController = TextEditingController(text: item.rate.toStringAsFixed(2));

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: TextFormField(
              controller: descController,
              decoration: const InputDecoration(labelText: 'Description', isDense: true),
              onChanged: (v) {
                item.description = v;
                onChanged();
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              controller: qtyController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Qty', isDense: true),
              onChanged: (v) {
                item.quantity = double.tryParse(v) ?? 0;
                onChanged();
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: TextFormField(
              controller: rateController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Rate', isDense: true),
              onChanged: (v) {
                item.rate = double.tryParse(v) ?? 0;
                onChanged();
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text(
                '${AppConstants.currencySymbol}${item.total.toStringAsFixed(2)}',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, size: 18),
            onPressed: onRemove,
          ),
        ],
      ),
    );
  }
}
