import 'package:flutter/material.dart';
import '../utils/theme.dart';

enum AppButtonVariant { primary, secondary, danger }

class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final AppButtonVariant variant;
  final IconData? icon;
  final bool isLoading;
  final bool fullWidth;

  const AppButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.variant = AppButtonVariant.primary,
    this.icon,
    this.isLoading = false,
    this.fullWidth = false,
  });

  Color get _bgColor {
    switch (variant) {
      case AppButtonVariant.primary:
        return AppTheme.primary;
      case AppButtonVariant.secondary:
        return Colors.white;
      case AppButtonVariant.danger:
        return AppTheme.danger;
    }
  }

  Color get _fgColor {
    switch (variant) {
      case AppButtonVariant.secondary:
        return AppTheme.primary;
      default:
        return Colors.white;
    }
  }

  @override
  Widget build(BuildContext context) {
    final child = isLoading
        ? SizedBox(
            height: 18,
            width: 18,
            child: CircularProgressIndicator(strokeWidth: 2, color: _fgColor),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[Icon(icon, size: 18), const SizedBox(width: 8)],
              Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          );

    final button = ElevatedButton(
      onPressed: isLoading ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: _bgColor,
        foregroundColor: _fgColor,
        elevation: variant == AppButtonVariant.secondary ? 0 : 1,
        side: variant == AppButtonVariant.secondary
            ? const BorderSide(color: AppTheme.primary)
            : BorderSide.none,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
      child: child,
    );

    return fullWidth ? SizedBox(width: double.infinity, child: button) : button;
  }
}
